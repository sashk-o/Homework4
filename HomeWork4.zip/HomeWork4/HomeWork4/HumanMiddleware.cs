﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork4
{
    public class HumanMiddleware
    {
        private readonly RequestDelegate _next;
        public Human Human { get; set; }
        public HumanMiddleware(RequestDelegate next, IOptions<Human> options)
        {
            _next = next;
            Human = options.Value;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            string str = "";
            str += $"Name: {Human.Name}\n";
            str += $"Age: {Human.Age}\n";
            str += $"Height: {Human.Height}\n";
            str += $"Skills:\n";
            foreach (var skill in Human.Skills)
            {
                str += $"\t{skill}\n";
            }
            str += $"Vacation:\n\tCountry: {Human.Vacation.Country}\n";
            str += $"\tAmount of days: {Human.Vacation.AmountOfDays}\n";

            await context.Response.WriteAsync(str);
        }
    }
}
