﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork4
{
    public class Vacation
    {
        public string Country { get; set; }
        public int AmountOfDays { get; set; }
    }
}
